console.log("~", process.env)
console.log("~~", process.env['npm_package_name'])
console.log("~~", process.env.npm_package_version)
